const http = require("http");
const fs=require("fs");
const path = require("path");
const url = require("url");
const queryString = require("querystring");

http.createServer((req,res)=>{
    var urlobj = url.parse(req.url,true);
    var urlpath = urlobj.pathname;
    console.log("路径名："+urlpath);
    // console.log(urlobj.query);
    switch(urlpath){
        case "/":
            res.write("page not find");
            res.end();
            break;
        case "/list":
            showList(res);
            break;
        case "/getContent":
            showListContent(res);
            break;
        case '/login_bg.jpg':
            getImg(res,urlpath);
            break;
        case '/js/baiduTemplate.js':
            getJs(res,urlpath);
            break;
        case "/detail":
            showMore(res,urlobj.query.chapterId);
            break;
        case "/login":
            showLogin(res);
            break;
        case "/listmanager":
        // case "/listmanager/":
            showListManager(res);
            break;
            // showManger(res);
            // break;
        case "/addChapter":
            addChapter(res,urlpath);
            break;
        case "/add":
            add(req,res);
            break;
        case "/check":
            check(req,res);
            break;
        case '/favicon.ico':
        case '/bg.jpg':
            res.end();
            break;
        default:
            if(urlpath.indexOf("images")>=0){
                if(urlpath.indexOf(".jpg")>=0||urlpath.indexOf(".jpeg")>=0){
                    getImg(res,urlpath);
                }
                else if(urlpath.indexOf(".png")>=0){
                    getPng(res,urlpath);
                }
            }
            else if(urlpath.indexOf("css")>=0){
                getCSS(res,urlpath);
            }
            else{
            console.log("资源路径出错");

            }
            // console.log("资源路径出错");
            break;
    }
}).listen(8083);
console.log("server is listening 8083");

var userList = [
    {username: "admin", pwd: "admin"}
]

var chapterList = [
    {
        "chapterId": 1,
        "chapterName": "hello ,这是后台取到的数据",
        "imgPath": "images/1442457564979540.jpeg",
        "chapterDes": "注定，有些路，只能一个人走；有些事，",
        "chapterContent": "有人说，生活生活，就是生下来活下去，也有人说，生容易，活容易，生活不容易。有个朋友曾经和我说，这个世界，大多数人都没有生活，他们有的仅仅是生存。我赞同这种说法吧，只是生存，对于我们可能都是一种奢侈。每个人都在努力，努力为着这个本来不属于我们的生活和努力。对于含着金钥匙而成长的人，我们又羡慕又嫉妒。可我们没有想过，他们的先人在斩荆棘的时候，付出的艰辛和艰苦，才有了后代荣华。生活是什么,其实在我看来，生活是一种需要，在你最需要亲人的时候，亲人已经突然不在了。子欲养而亲不待，说得成其深，对于我们是一种思考。他们的离开，对于我们都是一种打击，可也是一种思考。离开时痛苦的，可是生活就是有生老病死，当你一直都习惯存在的人已经离开的时候，慢慢地，你会看透很多，这就是你面对生活所需要的。生活是什么？其实在我看来，生活就是一种打拼，当过年过节的时候你看着别人的父母带着自己的孩子快乐的回家的时候、尔你还只能在大街上流浪的时候。许多游子和打工的人或许都有这种感觉吧，为了赚钱，为了养家。当我们看到留守儿童那迷茫孤寂的眼神，不由得心痛的时候，或许你能理解那份父母为了儿女在外打拼的奔波吧。其实在我看来，生活就是一种漠然，当你真正遇到困难而朋友都不能帮你的时候、怕你还不了钱的时候。你只能自己默默面对这一切，这一切让你十分无奈，可是你明白了一个道理，借给你是道理，不借给你是合理。人之常情，所以，想怪不能怪的时候，你留下的只是无奈。</p><p>生活是什么？</p><p>其实生活就是无奈的活着，不得不无奈的活着。我们活在这个世界上，为的只是寻找一个目标，而生活，给我们的感受，却是无奈与绝望的迷茫。这时候你不能说生活是美好和美满的吧？可是正因为有痛苦，无奈与悲伤，我们才有开心的日子。也正因为有了生存，才有了生活。</p><p>无奈的生活，才给我们无奈的心情，无奈的心情才有了悠然见南山的豁达与开朗，这就是生活，这种生活才会有着无限的魅力，也只有这种魅力才能吸引我们一直向前",
        "publishTimer": "2019-08-19",
        "author": "admin",
        "views": 1022
    },
    {
        "chapterId": 2,
        "chapterName": "那些不是事",
        "imgPath": "images/1442201163344838-lp.jpg",
        "chapterDes": "人生，原本就该这样。再大的事，无非是个经历而己。明天的太阳照样升起，就像罗俊杰个人博客​的时候水来土掩，兵来将挡。任何事情都会成为过去，只要有好的心态，就可以面对人生的.",
        "chapterContent": "有人说，生活生活，就是生下来活下去，也有人说，生容易，活容易，生活不容易。有个朋友曾经和我说，这个世界，大多数人都没有生活，他们有的仅仅是生存。我赞同这种说法吧，只是生存，对于我们可能都是一种奢侈。每个人都在努力，努力为着这个本来不属于我们的生活和努力。对于含着金钥匙而成长的人，我们又羡慕又嫉妒。可我们没有想过，他们的先人在斩荆棘的时候，付出的艰辛和艰苦，才有了后代荣华。生活是什么,其实在我看来，生活是一种需要，在你最需要亲人的时候，亲人已经突然不在了。子欲养而亲不待，说得成其深，对于我们是一种思考。他们的离开，对于我们都是一种打击，可也是一种思考。离开时痛苦的，可是生活就是有生老病死，当你一直都习惯存在的人已经离开的时候，慢慢地，你会看透很多，这就是你面对生活所需要的。生活是什么？其实在我看来，生活就是一种打拼，当过年过节的时候你看着别人的父母带着自己的孩子快乐的回家的时候、尔你还只能在大街上流浪的时候。许多游子和打工的人或许都有这种感觉吧，为了赚钱，为了养家。当我们看到留守儿童那迷茫孤寂的眼神，不由得心痛的时候，或许你能理解那份父母为了儿女在外打拼的奔波吧。其实在我看来，生活就是一种漠然，当你真正遇到困难而朋友都不能帮你的时候、怕你还不了钱的时候。你只能自己默默面对这一切，这一切让你十分无奈，可是你明白了一个道理，借给你是道理，不借给你是合理。人之常情，所以，想怪不能怪的时候，你留下的只是无奈。</p><p>生活是什么？</p><p>其实生活就是无奈的活着，不得不无奈的活着。我们活在这个世界上，为的只是寻找一个目标，而生活，给我们的感受，却是无奈与绝望的迷茫。这时候你不能说生活是美好和美满的吧？可是正因为有痛苦，无奈与悲伤，我们才有开心的日子。也正因为有了生存，才有了生活。</p><p>无奈的生活，才给我们无奈的心情，无奈的心情才有了悠然见南山的豁达与开朗，这就是生活，这种生活才会有着无限的魅力，也只有这种魅力才能吸引我们一直向前",
        "publishTimer": "2019-08-19",
        "author": "admin",
        "views": 102
    },
    {
        "chapterId": 3,
        "chapterName": "只想，留住心中的那份静美",
        "imgPath": "images/1442642178239101-lp.jpg",
        "chapterDes": "在这个鸟语花香的季节,踏着早晨罗俊杰个人博客的一缕光芒在小路间走着,呼吸着这自然的清晰空气，只想，衣袂飘飘，信步于绿荫小道，或俯首听花开，或低眉赏花香，盈脉脉春意，于眼波中...",
        "chapterContent": "有人说，生活生活，就是生下来活下去，也有人说，生容易，活容易，生活不容易。有个朋友曾经和我说，这个世界，大多数人都没有生活，他们有的仅仅是生存。我赞同这种说法吧，只是生存，对于我们可能都是一种奢侈。每个人都在努力，努力为着这个本来不属于我们的生活和努力。对于含着金钥匙而成长的人，我们又羡慕又嫉妒。可我们没有想过，他们的先人在斩荆棘的时候，付出的艰辛和艰苦，才有了后代荣华。生活是什么,其实在我看来，生活是一种需要，在你最需要亲人的时候，亲人已经突然不在了。子欲养而亲不待，说得成其深，对于我们是一种思考。他们的离开，对于我们都是一种打击，可也是一种思考。离开时痛苦的，可是生活就是有生老病死，当你一直都习惯存在的人已经离开的时候，慢慢地，你会看透很多，这就是你面对生活所需要的。生活是什么？其实在我看来，生活就是一种打拼，当过年过节的时候你看着别人的父母带着自己的孩子快乐的回家的时候、尔你还只能在大街上流浪的时候。许多游子和打工的人或许都有这种感觉吧，为了赚钱，为了养家。当我们看到留守儿童那迷茫孤寂的眼神，不由得心痛的时候，或许你能理解那份父母为了儿女在外打拼的奔波吧。其实在我看来，生活就是一种漠然，当你真正遇到困难而朋友都不能帮你的时候、怕你还不了钱的时候。你只能自己默默面对这一切，这一切让你十分无奈，可是你明白了一个道理，借给你是道理，不借给你是合理。人之常情，所以，想怪不能怪的时候，你留下的只是无奈。</p><p>生活是什么？</p><p>其实生活就是无奈的活着，不得不无奈的活着。我们活在这个世界上，为的只是寻找一个目标，而生活，给我们的感受，却是无奈与绝望的迷茫。这时候你不能说生活是美好和美满的吧？可是正因为有痛苦，无奈与悲伤，我们才有开心的日子。也正因为有了生存，才有了生活。</p><p>无奈的生活，才给我们无奈的心情，无奈的心情才有了悠然见南山的豁达与开朗，这就是生活，这种生活才会有着无限的魅力，也只有这种魅力才能吸引我们一直向前",
        "publishTimer": "2019-08-19",
        "author": "admin",
        "views": 202
    },
    {
        "chapterId": 4,
        "chapterName": "所以才会美",
        "imgPath": "images/1442539025939884-lp.jpg",
        "chapterDes": "人，越简单就会越快乐;水，掺杂东西越少才会显得清澈靓丽。大自然越安静,才会体现它的本质。人生就是这样，倘若有运，不用祈求，因为祈求也是无用。倘若无运，无需悲伤，因为悲...",
        "chapterContent": "有人说，生活生活，就是生下来活下去，也有人说，生容易，活容易，生活不容易。有个朋友曾经和我说，这个世界，大多数人都没有生活，他们有的仅仅是生存。我赞同这种说法吧，只是生存，对于我们可能都是一种奢侈。每个人都在努力，努力为着这个本来不属于我们的生活和努力。对于含着金钥匙而成长的人，我们又羡慕又嫉妒。可我们没有想过，他们的先人在斩荆棘的时候，付出的艰辛和艰苦，才有了后代荣华。生活是什么,其实在我看来，生活是一种需要，在你最需要亲人的时候，亲人已经突然不在了。子欲养而亲不待，说得成其深，对于我们是一种思考。他们的离开，对于我们都是一种打击，可也是一种思考。离开时痛苦的，可是生活就是有生老病死，当你一直都习惯存在的人已经离开的时候，慢慢地，你会看透很多，这就是你面对生活所需要的。生活是什么？其实在我看来，生活就是一种打拼，当过年过节的时候你看着别人的父母带着自己的孩子快乐的回家的时候、尔你还只能在大街上流浪的时候。许多游子和打工的人或许都有这种感觉吧，为了赚钱，为了养家。当我们看到留守儿童那迷茫孤寂的眼神，不由得心痛的时候，或许你能理解那份父母为了儿女在外打拼的奔波吧。其实在我看来，生活就是一种漠然，当你真正遇到困难而朋友都不能帮你的时候、怕你还不了钱的时候。你只能自己默默面对这一切，这一切让你十分无奈，可是你明白了一个道理，借给你是道理，不借给你是合理。人之常情，所以，想怪不能怪的时候，你留下的只是无奈。</p><p>生活是什么？</p><p>其实生活就是无奈的活着，不得不无奈的活着。我们活在这个世界上，为的只是寻找一个目标，而生活，给我们的感受，却是无奈与绝望的迷茫。这时候你不能说生活是美好和美满的吧？可是正因为有痛苦，无奈与悲伤，我们才有开心的日子。也正因为有了生存，才有了生活。</p><p>无奈的生活，才给我们无奈的心情，无奈的心情才有了悠然见南山的豁达与开朗，这就是生活，这种生活才会有着无限的魅力，也只有这种魅力才能吸引我们一直向前",
        "publishTimer": "2019-08-19",
        "author": "admin",
        "views": 102
    }
]

function showListContent(res){
    var str = JSON.stringify(chapterList);
    res.end(str); 
}

function getCSS(res,urlpath){

    var filepath = path.join(__dirname,urlpath);
    var fileContent = fs.readFileSync(filepath);
    res.writeHead(200,{"content-type":"text/css"});
    res.write(fileContent);
    res.end();
}

function getImg(res,urlpath){
    var filepath = path.join(__dirname,urlpath);
    var fileContent = fs.readFileSync(filepath);
    res.writeHead(200,{"content-type":"img/jpg"});
    res.write(fileContent);
    res.end();
}

function getPng(res,urlpath){
    var filepath = path.join(__dirname,urlpath);
    var fileContent = fs.readFileSync(filepath);
    res.writeHead(200,{"content-type":"img/png"});
    res.write(fileContent);
    res.end();
}

function showList(res){
    var filepath = path.join(__dirname,"chapterList.html");
    var fileContent = fs.readFileSync(filepath);
    res.writeHead(200,{"content-type":"text/html"});
    res.write(fileContent);
    res.end();
}

function getJs(res,urlpath){
    var filepath = path.join(__dirname,urlpath);
    var fileContent = fs.readFileSync(filepath);
    res.writeHead(200,{"content-type":"javascript"});
    res.write(fileContent);
    res.end();
}



function showMore(res,id){
    console.log(id);
    var filepath = path.join(__dirname,"chapter.html");
    var fileContent =fs.readFileSync(filepath);
    res.writeHead(200,{"content-type":"text/html"});
    res.write(fileContent);
    res.end();
}


function showLogin(res){
    var filepath = path.join(__dirname,"login.html");
    var fileContent =fs.readFileSync(filepath);
    res.writeHead(200,{"content-type":"text/html"});
    res.write(fileContent);
    res.end();
}

function check(req,res){
    var str = '';
    req.on("data",(chunk)=>{
        str += chunk;
        console.log(chunk);
    });
    req.on("end",()=>{
        
        var queryobj = queryString.parse(str);
        console.log(queryobj);
        for(var i=0;i<userList.length;i++){
            if(userList[i].username === queryobj.username && userList[i].pwd === queryobj.pwd){
                showListManager(res);
                // res.write("success");
                res.end("success");
            }
            else{
                res.write("用户名或密码错误");
                res.end();
            }
        }
    })
}


function showListManager(res){
    var filepath = path.join(__dirname,"list.html");
    var fileContent = fs.readFileSync(filepath);
    res.writeHead(200,{"content-type":"text/html"});
    res.write(fileContent);
    res.end();
} 

function addChapter(res,urlpath){
    var filepath = path.join(__dirname,urlpath+".html");
    var fileContent = fs.readFileSync(filepath);
    res.writeHead(200,{"content-type":"text/html"});
    res.write(fileContent);
    res.end();
}

function add(req,res){
    var str = "";
    var articleObj = {};
    req.on("data",(chunk)=>{
        str += chunk;
    });

    req.on("end",()=>{
        var jsonobj = queryString.parse(str);
        var date = new Date();
        var timer = date.getFullYear()+"年-"+(date.getMonth()+1)+"月-"+date.getDate()+"日";
        articleObj.chapterId = chapterList.length+1;
        articleObj.chapterName = jsonobj.title;
        articleObj.imgPath="images/1433907491564146.png";
        articleObj.chapterDes=jsonobj.content;
        articleObj.chapterContent = jsonobj.content;
        articleObj.publishTimer=timer;
        articleObj.author="admin";
        articleObj.views = Math.random()*100+3;
        chapterList.push(articleObj);
    })
    res.end("success");
}